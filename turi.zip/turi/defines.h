#pragma once

enum DIRECTION { LEFT, NONE, RIGHT };

enum ERROR_TYPE { ERROR, WARNING };

#define ANY_SYMBOL '*'
