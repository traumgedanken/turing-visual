#include "turicarette.h"
#include <QDebug>
#include <QPainter>
#include <QPicture>
#include <exceptionmessage.h>
#include <QThread>

TuriCarette::TuriCarette(QString _word, QLabel * _label, QString & _currentState) {
    label = _label;
    for (int i = 0; i < 100; i++)
        word.append(' ');
    int wordLength = _word.length();
    position = (100 - wordLength) / 2;
    word.replace(position, wordLength, _word);
    currentState = _currentState;
}

int TuriCarette::exec(TuriProgram * program) {

//    while (true) {
        TuriCommand * currentCommand = nullptr;
        for (int i = 0; i < program->count(); i++) {
            TuriCommand * command = program->getCommand(i);
            if (command->getCurrentState() == currentState &&
                (command->getCurrentSymbol() == getSymbol() ||
                 command->getCurrentSymbol() == ANY_SYMBOL)) {
                currentCommand = command;
                break;
            }
        }
        if (currentCommand == nullptr) return -1;
        setSymbol(currentCommand->getNextSymbol());
        setState(currentCommand->getNextState());
        move(currentCommand->getDirection());
        drawWord();
        if (currentState == "!") return 1;
    //}
    return 0;
}

QString TuriCarette::getResult() {
    QString result;
    int start = 0;
    int end = word.length() - 1;
    while (word.at(start) == ' ')
        start++;
    while (word.at(end) == ' ')
        end--;
    for (int i = start; i <= end; i++)
        result.append(word.at(i));
    return result;
}

void TuriCarette::move(DIRECTION direction) {
    if (direction == LEFT) {
        position--;
    } else if (direction == RIGHT)
        position++;
}

QChar TuriCarette::getSymbol() { return word.at(position); }

void TuriCarette::setSymbol(QChar symbol) { word.replace(position, 1, symbol); }

void TuriCarette::setState(QString state) { currentState = state; }

void TuriCarette::drawTable() {
    QPicture pi;
    QPainter p(&pi);

    p.setRenderHint(QPainter::Antialiasing);

    p.setPen(Qt::NoPen);
    p.setBrush(QColor(120, 180, 150));
    p.drawRect((currentCellNumber - 1) * cellWidth, 0, cellWidth, cellHeigth);

    p.setPen(QPen(Qt::darkGray, 2));
    p.drawRect((currentCellNumber - 1) * cellWidth, cellHeigth, cellWidth, 50);
    for (int i = cellWidth; i < caretteWidth; i += cellWidth) {
        p.drawLine(i, 0, i, cellHeigth);
    }
    p.end();
    label->setPicture(pi);
}

void TuriCarette::drawWord() {
    label->clear();
    QPicture pi;
    QPainter p(&pi);

    p.setRenderHint(QPainter::Antialiasing);

    p.setPen(Qt::NoPen);
    p.setBrush(QColor(120, 180, 150));
    p.drawRect((currentCellNumber - 1) * cellWidth, 0, cellWidth, cellHeigth);

    p.setPen(QPen(Qt::darkGray, 2));
    p.drawLine(0, 0, caretteWidth, 0);
    p.drawLine(0, cellHeigth, caretteWidth, cellHeigth);
    p.drawRect((currentCellNumber - 1) * cellWidth, cellHeigth, cellWidth, 25);
    for (int i = cellWidth; i < caretteWidth; i += cellWidth) {
        p.drawLine(i, 0, i, cellHeigth);
    }

    p.setPen(QPen(Qt::black));
    QFont font = p.font() ;
    font.setPointSize(25);
    p.setFont(font);
    for (int i = 0; i < cellNumber; i++) {
        QString ch = word.at(position + i - currentCellNumber + 1);
        p.drawText(i * cellWidth, 0, cellWidth, cellHeigth, Qt::AlignCenter, ch);
    }
    font.setPointSize(10);
    p.setFont(font);
    p.drawText((currentCellNumber - 1) * cellWidth, cellHeigth, cellWidth, 25, Qt::AlignCenter, currentState);
    p.end();
    label->setPicture(pi);
    //QObject().thread()->usleep(1000*1000*2);
}
