#pragma once

#include <QString>
#include <turiprogram.h>
#include <QLabel>

class TuriCarette {
    QString word;
    int position;
    QString currentState;
    QLabel * label = nullptr;

    static const int caretteWidth = 800;
    static const int cellNumber = 20;
    static const int currentCellNumber = cellNumber / 2 - 2;
    static const int cellWidth = caretteWidth / cellNumber;
    static const int cellHeigth = 50;

  public:
    TuriCarette() {}
    TuriCarette(QString _word, QLabel * label, QString & _currentState);

    int exec(TuriProgram * program);

    QString getResult();

    void drawTable();

    void drawWord();

  private:
    void move(DIRECTION direction);

    QChar getSymbol();

    void setSymbol(QChar symbol);

    void setState(QString state);
};
